<?php
    if(!empty($_GET['UID']))
    {
        require_once $_SERVER['DOCUMENT_ROOT'] . "/vendor/autoload.php";
        require_once $_SERVER['DOCUMENT_ROOT'] . "/include/database.php";

        $id = $_GET['UID'];

        Database::$membership->delete('Accounts', ['AccountID' => $id]);

        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit;
    }
    else
    {
        header("Location: /");
    }