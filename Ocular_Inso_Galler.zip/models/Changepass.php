<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="keywords" content="" />
	    <meta name="description" content="" />
	    <meta name="viewport" content="width=1280, maximum-scale=1">
        <title>Dragon Nest Adventure</title>
        <link href="/assets/library/assets/css/css-reset.css" rel="stylesheet">
	    <link href='https://fonts.googleapis.com/css?family=Titillium Web' rel='stylesheet'>
	    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
	    <link rel="stylesheet" href="/assets/library/assets/css/flags.css" type="text/css">
	    <link href="/assets/library/assets/css/custom.css?v=1.2" rel="stylesheet">
        <link href="/assets/library/assets/css/style.css?v=1" rel="stylesheet">
	    <link href="/assets/library/assets/css/syntax.css?v=1" rel="stylesheet">
        <style>
            *, body, a, td, tr, span, strong, font, p {
                font-family: 'Titillium Web', 'Open Sans', 'Candara', Arial !important;
            }
            ::-webkit-scrollbar {
                width: 0px !important;
            }
            .cke_reset_all, .cke_reset_all *, .cke_reset_all a, .cke_reset_all textarea {
                color: black !important;
            }
            ul { 
                list-style-type: none;
            }
            .top li .nickname {
                width: 100%;
            }
            #inside .in, #inside a {
                display: block;
            }
            textarea.cke_source {
                color: black !important;
            }
            pre {
                overflow: hidden !important;
            }
        </style>
    </head>
    <body>
        <div class="wrapper">
            <header class="header">
                <div class="top-panel flex-s-c">
                    <ul class="menu">
                        <?php
                            if(!isset($_SESSION['AccountID']))
                            {
                        ?>
                        <li>
                            <a href="/">Home</a>
                        </li>
                        <li>
                            <a href="/Register.php">Register</a>
                        </li>
                        <li>
                            <a href="/Downloads">Download</a>
                        </li>
                        <?php
                            }
                            else
                            {
                        ?>
                        <li>
                            <a href="/">Home</a>
                        </li>
                        <li>
                            <a href="/Downloads">Download</a>
                        </li>
                        <?php
                            }
                        ?>
                    </ul>
                </div>
                <div class="logo">
                    <a href="/"><img src="https://static.wikia.nocookie.net/dnsea/images/b/bf/DragonNestA.png" alt="Logo"></a>
                </div>
            </header>
            <div class="container">
                <main class="content">
                    <?php
                        if($error)
                        {
                            error_msg();
                        }
                        else
                        {
                    ?>
                    <div class='login-block'>
                        <?php
                            error_msg();
                            success_msg();
                        ?>
                        <p>Change Password</p>
                        <form action="" method="post">
                            <input type="password" id="password_input" name="oldPassword" placeholder="Old Password" required>
                            <input type="password" id="password_input" name="newPassword" placeholder="New Password" required>
                            <input name="submit" type="hidden" value="changepass">
                            <center>
                                <button id="submit" type="submit">Change Password</button>
                            </center>
                        </form>
                    </div>
                    <?php
                        }
                    ?>
                </main>
                <aside class="sidebar">
                    <div class="download-button flex-c-c">
                        <a href="/Downloads"><span>Download</span> Download files to play a game</a>
                    </div>
                    <div class="login-block" id="Login-form">
                        <?php
                            if(isset($_SESSION['AccountID']))
                            {
                        ?>
                        <div id='inside'>
                            <ul class='style4'>
                                <div class='first' style='text-align: center;padding-bottom: 20px;color:#fff;'>
                                    Welcome, <b> <?php echo $_SESSION['AccountName']; ?> </b>!
                                </div>
                                <div class='white-box acc-menu'>
                                    <div class='in'>Cash: <span class='my_credits'><?php echo $_SESSION['Cash']; ?></span>
                                        <?php
                                            if($_SESSION['AccountLevelCode'] >= 30)
                                            {
                                        ?>
                                        <a class='without_img' href='/Admin.php?field=cash'>Admin Panel(Cash)</a>
                                        <a class='without_img' href='/Admin.php?field=accounts'>Admin Panel(Accounts)</a>
                                        <?php
                                            }
                                        ?>
                                        <a class='without_img' href='/Characters.php?username=<?php echo $_SESSION["AccountName"]?>'>View Characters</a>
                                        <a class='codecs' href='/logout.php'>Logout</a>
                                    </div>
                                </div>
                            </ul>
                        </div>
                        <?php
                            }
                        ?>
                    </div>
                    <div class="widget">
                        <span class="widget-title flex-c-c">Visitor Info</span>
                        <ul>
                            <li>
                                IP Address:
                                <span class="badge">
                                    <span id="ServerTime"><?php echo GeoLocation::GetVisitorInfo()->query; ?></span>
                                </span>
                            </li>
                            <li>
                                Country:
                                <span class="badge">
                                    <span id="ServerTime"><img src='<?php echo GeoLocation::GetCountryInfo(GeoLocation::GetVisitorInfo()->countryCode)->flags->png; ?>' alt="_blank" width="15px" height="10px"/>  <?php echo GeoLocation::GetVisitorInfo()->country; ?></span>
                                </span>
                            </li>
                        </ul>
                    </div>
                    <div class="widget">
                        <span class="widget-title flex-c-c">Server Statistics</span>
                        <ul>
                            <li>
                                Server Time:
                                <span class="badge">
                                    <span id="ServerTime"><?php
                                            date_default_timezone_set(GeoLocation::GetVisitorInfo()->timezone);
                                            echo date('h:i A', time());
                                        ?>
                                    </span>
                                </span>
                            </li>
                            <li>
                                Online Players:
                                <span class="badge">
                                    <span id="ServerTime"><?php echo User::GetOnlineUser(); ?></span>
                                </span>
                            </li>
                            <li>
                                Accounts:
                                <span class="badge">
                                    <span id="ServerTime"><?php echo User::GetAccountCount(); ?></span>
                                </span>
                            </li>
                            <li>
                                Characters:
                                <span class="badge">
                                    <span id="ServerTime"><?php echo User::GetCharacterCount(); ?></span>
                                </span>
                            </li>
                            <li>
                                Guilds:
                                <span class="badge">
                                    <span id="ServerTime"><?php echo User::GetGuildCount(); ?></span>
                                </span>
                            </li>
                        </ul>
                    </div>
                    <div class='widget'>
                        <span class='widget-title flex-c-c'>Server INFORMATION</span>
                        <ul>
                            <li>
                                Drops:
                                <span class='badge'>
                                        <span id='ServerTime'>x1 (Normal)</span>
                                </span>
                            </li>
                            <li>
                                Exp:
                                <span class='badge'>
                                    <span id='ServerTime'>x1 (Normal)</span>
                                </span>
                            </li>
                            <li>
                                Gold Drop:
                                <span class='badge'>
                                    <span id='ServerTime'>x1 (Normal)</span>
                                </span>
                            </li>
                            <li>
                                Nest Reset:
                                <span class='badge'>
                                    <span id='ServerTime'>Wednesday | Friday | Sunday</span>
                                </span>
                            </li>
                        </ul>
                    </div>
                </aside>
            </div>
            <footer class="footer">
                <div class="flex-s-c f-block">

                </div>
                <div class="copyright">
                    Copyright <?php echo date("Y"); ?> &copy; <a href='.'>Dragon Nest Adventure</a> <br> All Rights Reserved
                </div>
            </footer>
        </div>
        <script src="/assets/library/assets/javascript/jquery-2.1.4.min.js"></script>
        <script src="/assets/library/assets/javascript/app.min.js"></script>
    </body>
</html>