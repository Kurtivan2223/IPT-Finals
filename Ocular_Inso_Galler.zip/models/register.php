<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="keywords" content="" />
	    <meta name="description" content="" />
	    <meta name="viewport" content="width=1280, maximum-scale=1">
        <title>Dragon Nest Adventure</title>
        <link href="/assets/library/assets/css/css-reset.css" rel="stylesheet">
	    <link href='https://fonts.googleapis.com/css?family=Titillium Web' rel='stylesheet'>
	    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
	    <link rel="stylesheet" href="/assets/library/assets/css/flags.css" type="text/css">
	    <link href="/assets/library/assets/css/custom.css?v=1.2" rel="stylesheet">
        <link href="/assets/library/assets/css/style.css?v=1" rel="stylesheet">
	    <link href="/assets/library/assets/css/syntax.css?v=1" rel="stylesheet">
        <style>
            *, body, a, td, tr, span, strong, font, p {
                font-family: 'Titillium Web', 'Open Sans', 'Candara', Arial !important;
            }
            ::-webkit-scrollbar {
                width: 0px !important;
            }
            .cke_reset_all, .cke_reset_all *, .cke_reset_all a, .cke_reset_all textarea {
                color: black !important;
            }
            ul { 
                list-style-type: none;
            }
            .top li .nickname {
                width: 100%;
            }
            #inside .in, #inside a {
                display: block;
            }
            textarea.cke_source {
                color: black !important;
            }
            pre {
                overflow: hidden !important;
            }
        </style>
    </head>
    <body>
        <div class="wrapper">
            <header class="header">
                <div class="top-panel flex-s-c">
                    <ul class="menu">
                        <li>
                            <a href="/">Home</a>
                        </li>
                        <li>
                            <a href="/Register.php">Register</a>
                        </li>
                        <li>
                            <a href="/Downloads">Download</a>
                        </li>
                    </ul>
                </div>
                <div class="logo">
                    <a href="/"><img src="https://static.wikia.nocookie.net/dnsea/images/b/bf/DragonNestA.png" alt="Logo"></a>
                </div>
            </header>
            <div class="container">
                <main class="content">
                    <div class='login-block'>
                        <?php
                            error_msg();
                            success_msg();
                        ?>
                        <p>Register</p>
                        <form action="" method="post">
                            <input type="email" id="email_input" name="email" placeholder="E-mail" required>
                            <input type="text" id="username_input" name="username" placeholder="Username" required>
                            <input type="password" id="password_input" name="password" placeholder="Password" required>
                            <input type="password" id="password_input" name="repassword" placeholder="Re-type Password" required>
                            <p>Birthdate</p>
                            <input type="date" id="bday_input" name="birth" required>
                            <p>Gender</p>
                            <select name="gender" required>
								<option value="">Select Gender</option>
								<option value="1">Male</option>
								<option value="2">Female</option>
							</select>
                            <input name="submit" type="hidden" value="register">
                            <center>
                                <button id="submit" type="submit">Submit</button>
                            </center>
                        </form>
                    </div>
                </main>
                <aside class="sidebar">
                    <div class="download-button flex-c-c">
                        <a href="/Downloads"><span>Download</span> Download files to play a game</a>
                    </div>
                    <div class="widget">
                        <span class="widget-title flex-c-c">Visitor Info</span>
                        <ul>
                            <li>
                                IP Address:
                                <span class="badge">
                                    <span id="ServerTime"><?php echo GeoLocation::GetVisitorInfo()->query; ?></span>
                                </span>
                            </li>
                            <li>
                                Country:
                                <span class="badge">
                                    <span id="ServerTime"><img src='<?php echo GeoLocation::GetCountryInfo(GeoLocation::GetVisitorInfo()->countryCode)->flags->png; ?>' alt="_blank" width="15px" height="10px"/>  <?php echo GeoLocation::GetVisitorInfo()->country; ?></span>
                                </span>
                            </li>
                        </ul>
                    </div>
                    <div class="widget">
                        <span class="widget-title flex-c-c">Server Statistics</span>
                        <ul>
                            <li>
                                Server Time:
                                <span class="badge">
                                    <span id="ServerTime"><?php
                                            date_default_timezone_set(GeoLocation::GetVisitorInfo()->timezone);
                                            echo date('h:i A', time());
                                        ?>
                                    </span>
                                </span>
                            </li>
                            <li>
                                Online Players:
                                <span class="badge">
                                    <span id="ServerTime"><?php echo User::GetOnlineUser(); ?></span>
                                </span>
                            </li>
                            <li>
                                Accounts:
                                <span class="badge">
                                    <span id="ServerTime"><?php echo User::GetAccountCount(); ?></span>
                                </span>
                            </li>
                            <li>
                                Characters:
                                <span class="badge">
                                    <span id="ServerTime"><?php echo User::GetCharacterCount(); ?></span>
                                </span>
                            </li>
                            <li>
                                Guilds:
                                <span class="badge">
                                    <span id="ServerTime"><?php echo User::GetGuildCount(); ?></span>
                                </span>
                            </li>
                        </ul>
                    </div>
                    <div class='widget'>
                        <span class='widget-title flex-c-c'>Server INFORMATION</span>
                        <ul>
                            <li>
                                Drops:
                                <span class='badge'>
                                        <span id='ServerTime'>x1 (Normal)</span>
                                </span>
                            </li>
                            <li>
                                Exp:
                                <span class='badge'>
                                    <span id='ServerTime'>x1 (Normal)</span>
                                </span>
                            </li>
                            <li>
                                Gold Drop:
                                <span class='badge'>
                                    <span id='ServerTime'>x1 (Normal)</span>
                                </span>
                            </li>
                            <li>
                                Nest Reset:
                                <span class='badge'>
                                    <span id='ServerTime'>Wednesday | Friday | Sunday</span>
                                </span>
                            </li>
                        </ul>
                    </div>
                </aside>
            </div>
            <footer class="footer">
                <div class="flex-s-c f-block">

                </div>
                <div class="copyright">
                    Copyright <?php echo date("Y"); ?> &copy; <a href='.'>Dragon Nest Adventure</a> <br> All Rights Reserved
                </div>
            </footer>
        </div>
        <script src="/assets/library/assets/javascript/jquery-2.1.4.min.js"></script>
        <script src="/assets/library/assets/javascript/app.min.js"></script>
    </body>
</html>