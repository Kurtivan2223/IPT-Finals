<?php
    session_start();

    require_once $_SERVER['DOCUMENT_ROOT'] . "/vendor/autoload.php";
    require_once $_SERVER['DOCUMENT_ROOT'] . "/include/ip.php";
    require_once $_SERVER['DOCUMENT_ROOT'] . "/include/function.php";
    require_once $_SERVER['DOCUMENT_ROOT'] . "/include/database.php";
    require_once $_SERVER['DOCUMENT_ROOT'] . "/include/user.php";

    User::_postHandler();

    $error = false;

    if(!isset($_SESSION['AccountID']))
    {
        header('Location: /');
    }
    else
    {
        if($_GET['username'] != $_SESSION['AccountName'])
        {
            $error = true;
            error_msg('Something Went Wrong!');
        }
    }

    require_once $_SERVER['DOCUMENT_ROOT'] . "/models/Changepass.php";
?>