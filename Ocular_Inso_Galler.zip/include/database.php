<?php
    use Medoo\Medoo;

    class Database
    {
        public static $membership;
        public static $world;

        public static function Connect()
        {
            self::$membership = new Medoo([
                'type' => 'mssql',
                'host' => '127.0.0.1',
                'database' => 'DNMembership',
                'username' => 'DragonNest',
                'password' => 'E6h7HsRXJbH8ays',
                'port' => 1433,
                'driver' => 'sqlsrv',
                'option' => [
                    //PDO::ATTR_ERRMODE => PDO::ERRMODE_SILENT
                    //PDO::ERRMODE_WARNING
                    //PDO::ERRMODE_EXCEPTION
                ]
            ]);

            self::$world = new Medoo([
                'type' => 'mssql',
                'host' => '127.0.0.1',
                'database' => 'DNWorld',
                'username' => 'DragonNest',
                'password' => 'E6h7HsRXJbH8ays',
                'port' => 1433,
                'driver' => 'sqlsrv',
                'option' => [
                    //PDO::ATTR_ERRMODE => PDO::ERRMODE_SILENT
                    //PDO::ERRMODE_WARNING
                    //PDO::ERRMODE_EXCEPTION
                ]
            ]);
        }
    }

    Database::Connect();