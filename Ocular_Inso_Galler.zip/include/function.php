<?php
    $error_msg = "";
    $success_msg = "";

    function error_msg($input = false)
    {
        global $error_error;
        if (!empty($error_error)) {
            echo "<p class=\"alert alert-danger\">$error_error</p>";
        } elseif (!empty($input)) {
            $error_error = $input;
        }
    }

    function success_msg($input = false)
    {
        global $success_msg;
        if (!empty($success_msg)) {
            echo "<p class=\"alert alert-success\">$success_msg</p>";
        } elseif (!empty($input)) {
            $success_msg = $input;
        }
    }

    function GetJobName($JID)
    {
        switch ($JID)
        {
        case 1:
            return "Warrior";
        case 2:
            return "Archer";
        case 3:
            return "Soceress";
        case 4:
            return "Cleric";
        case 5:
            return "Academic";
        case 6:
            return "Kali";                
        case 7:
            return "Assassin";                
        case 8:
            return "Lancea";               
        case 9:
            return "Machina";
        case 10:
            return "Vandar";
        case 11:
            return "Swordsmaster";
        case 12:
            return "Mercenary";
        case 14:
            return "Bowmaster";
        case 15:
            return "Acrobat";
        case 17:
            return "Elemental Lord";
        case 18:
            return "Force User";
        case 19:
            return "Warlock";
        case 20:
            return "Paladin";
        case 21:
            return "Monk";
        case 22:
            return "Priest";
        case 23:
            return "Gladiator";
        case 24:
            return "Moon Lord";
        case 25:
            return "Barbarian";
        case 26:
            return "Destroyer";
        case 29:
            return "Sniper";
        case 30:
            return "Artillery";
        case 31:
            return "Tempest";
        case 32:
            return "Wind Walker";
        case 35:
            return "Saleana";
        case 36:
            return "Elestra";
        case 37:
            return "Smasher";
        case 38:
            return "Majesty";
        case 41:
            return "Guardian";
        case 42:
            return "Crusador";
        case 43:
            return "Saint";
        case 44:
            return "Inquisitor";
        case 45:
            return "Exorcist";
        case 46:
            return "Engineer";
        case 47:
            return "Shooting Star";
        case 48:
            return "Gear Master";
        case 49:
            return "Alchemist";
        case 50:
            return "Adept";
        case 51:
            return "Physician";
        case 54:
            return "Screamer";
        case 55:
            return "Dark Summoner";
        case 56:
            return "Soul Eater";
        case 57:
            return "Dancer";
        case 58:
            return "Blade Dancer";
        case 59:
            return "Spirit Dancer";
        case 62:
            return "Chaser";
        case 63:
            return "Ripper";
        case 64:
            return "Raven";
        case 67:
            return "Bringer";
        case 68:
            return "Light Fury";
        case 69:
            return "Abyss Walker";
        case 72:
            return "Piercer";
        case 73:
            return "Flurry";
        case 74:
            return "Sting Breezer";
        case 75:
            return "Avenger";
        case 76:
            return "Dark Avenger";
        case 77:
            return "Patrona";
        case 78:
            return "Defensio";
        case 79:
            return "Ruina";
        case 80:
            return "Hunter";
        case 81:
            return "Silver Hunter";
        case 82:
            return "Heretic";
        case 83:
            return "Arc Heretic";
        case 84:
            return "Mara";
        case 85:
            return "Black Mara";
        case 86:
            return "Mechanic";
        case 87:
            return "Ray Mechanic";
        case 88:
            return "Oracle";
        case 89:
            return "Oracle Elder";
        case 90:
            return "Phantom";
        case 91:
            return "Bleed Phantom";  
        case 92:
            return "Knightess";
        case 93:
            return "Avalanche";
        case 94:
            return "Randgrid";
        case 95:
            return "Launcher";   
        case 96:
            return "Impactor";
        case 97:
            return "Lustre";
        case 98:
            return "Plaga";
        case 99:
            return "Vena Plaga";
        case 100:
            return "Treasure Hunter";
        case 102:
            return "Duelist";
        case 103:
            return "Trickster";               
        case 106:
            return "Knight";               
        case 107:
            return "Mystic Knight";
        case 108:
            return "Grand Master";
        default:
            exit("Can't Retrieve Job Name");
        }
    }