<?php
    class GeoLocation
    {
        public static function GetVisitorInfo()
        {
            $ip = "";

            if(!empty($_SERVER['HTTP_CLIENT_IP']))
            {  
                $ip = $_SERVER['HTTP_CLIENT_IP'];  
            }  
            elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
            {  
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
            }   
            else
            {  
                $ip = $_SERVER['REMOTE_ADDR'];
            }

            $curl = curl_init();

            curl_setopt_array(
                $curl,
                [
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_HTTPHEADER => [
                        'Content-type: application/json'
                    ],
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_URL => "http://ip-api.com/json/{$ip}?fields=66846719",
                ]
            );

            $response = curl_exec($curl);
            
            if(curl_errno($curl))
            {
                echo 'cURL error: ' . curl_error($curl);
            }

            curl_close($curl);

            $data = json_decode($response);

            if(!empty($data))
                return $data;
        }

        public static function GetCountryInfo($CountryCode)
        {

            $curl = curl_init();

            curl_setopt_array(
                $curl,
                [
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_HTTPHEADER => [
                        'Content-type: application/json'
                    ],
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_URL => "https://restcountries.com/v2/alpha/{$CountryCode}",
                ]
            );

            $response = curl_exec($curl);
            
            if(curl_errno($curl))
            {
                echo 'cURL error: ' . curl_error($curl);
            }

            curl_close($curl);

            $data = json_decode($response);

            if(!empty($data))
                return $data;
        }
    }