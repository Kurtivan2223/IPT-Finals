<?php
    use Medoo\Medoo;
    class User
    {
        public static function GetOnlineUser()
        {
            $data = Database::$membership->count('DNAuth', '*', ['CertifyingStep[>=]' => 1]);

            if(!empty($data))
            {
                return $data;
            }

            return "0";
        }

        public static function GetCharacterCount()
        {
            $data = Database::$world->count('Characters', '*');

            if(!empty($data))
            {
                return $data;
            }

            return "0";
        }

        public static function GetAccountCount()
        {
            $data = Database::$membership->count('Accounts', '*');

            if(!empty($data))
            {
                return $data;
            }

            return "0";
        }

        public static function GetGuildCount()
        {
            $data = Database::$world->count('Guilds', '*');

            if(!empty($data))
            {
                return $data;
            }

            return "0";
        }

        public static function _postHandler()
        {
            if(!empty($_POST['submit']))
            {
                self::register();
                self::login();
                self::changepass();
                self::updateCash();
            }
        }

        public static function register()
        {
            if($_POST['submit'] != 'register' || empty($_POST['email']) || empty($_POST['username']) || empty($_POST['password']) || empty($_POST['repassword']) || empty($_POST['gender']) || empty($_POST['birth']))
            {
                return false;
            }

            if (!preg_match('/^[0-9A-Z-_]+$/', strtoupper($_POST['username']))) {
                error_msg('Please use a unique username!');
                return false;
            }
    
            if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
                error_msg('Please use Valid Email!');
                return false;
            }
    
            if ($_POST['password'] != $_POST['repassword']) {
                error_msg('Password doesn`t matched!');
                return false;
            }
    
            if (!(strlen($_POST['password']) >= 4 && strlen($_POST['password']) <= 16)) {
                error_msg('Password should be atleast 4 - 16 in length!');
                return false;
            }
    
            if (!(strlen($_POST['username']) >= 4 && strlen($_POST['username']) <= 16)) {
                error_msg('Username should be atleast 4 - 16 in length!');
                return false;
            }

            if(!self::CheckEmailExists($_POST['email']))
            {
                error_msg('Email already used!');
                return false;
            }

            if(!self::CheckUsernameExists($_POST['username']))
            {
                error_msg('Username already used!');
                return false;
            }

            $ip = GeoLocation::GetVisitorInfo()->query;
            $country = GeoLocation::GetVisitorInfo()->countryCode;

            if(!self::CheckIPExists($ip))
            {
                error_msg('You can only Register once!');
                return false;
            }

            $username = $_POST['username'];
            $password = $_POST['password'];
            $email = $_POST['email'];
            $birth = $_POST['birth'];
            $gender = $_POST['gender'];
            //string(46) "EXEC [dbo].[P_AddAccountNew](?, ?, ?, ?, ?, ?)" array(6) { [0]=> string(9) "kurtivan1" [1]=> string(11) "Kurtgaller1" [2]=> string(23) "kurtgaller1@outlook.com" [3]=> string(12) "120.28.24.94" [4]=> string(10) "2023-05-09" [5]=> string(1) "1" }

            $stmt = Database::$membership->pdo->prepare("EXEC [dbo].[P_AddAccountNew] ?, ?, ?, ?, ?, ?");
			$stmt->execute([$username, $password, $email, $ip, $birth, $gender]);
			$result = $stmt->fetchAll();

            if($result[0]['result'] != 0)
            {
                error_msg("Something went Wrong!");
                return false;
            }

            $data = [
                'ip' => $ip,
                'country' => $country,
                'registered' => Database::$membership->raw('GETDATE()'),
            ];

            Database::$membership->insert('ip', $data);

            success_msg("Successfully Registered!");
            return true;
        }

        public static function login()
        {
            if($_POST['submit'] != 'login' || empty($_POST['username']) || empty($_POST['password']))
            {
                return false;
            }

            $RLKTPassword = strtoupper(md5($_POST['password']));

            $data = Database::$membership->count('Accounts', '*', ["AND" => ['AccountName' => $_POST['username'], 'RLKTPassword' => $RLKTPassword]]);

            if($data > 0)
            {

                $account = Database::$membership->select('Accounts', '*', ["AND" => ['AccountName' => $_POST['username'], 'RLKTPassword' => $RLKTPassword]]);

                $_SESSION['AccountID'] = $account[0]['AccountID'];
                $_SESSION['AccountName'] = $account[0]['AccountName'];
                $_SESSION['AccountLevelCode'] = $account[0]['AccountLevelCode'];
                $_SESSION['email'] = $account[0]['email'];
                $_SESSION['Cash'] = $account[0]['Cash'];

                return true;
            }

            error_msg("Account Doesn`t Exists!");
            return false;
        }

        public static function changepass()
        {
            if($_POST['submit'] != 'changepass' || empty($_POST['oldPassword']) || empty($_POST['newPassword']))
            {
                return false;
            }

            $oldPassword = strtoupper(md5($_POST['oldPassword']));
            $newPassword = strtoupper(md5($_POST['newPassword']));

            $data = Database::$membership->count('Accounts', '*', ["AND" => ['AccountName' => $_GET['username'], 'RLKTPassword' => $oldPassword]]);

            if($data > 0)
            {
                Database::$membership->update('Accounts', ['RLKTPassword' => $newPassword], ['AccountName' => Medoo::raw(':AccountName', [':AccountName' => $_GET['username']])]);

                success_msg('Successfully Updated the Password!');
                return true;
            }

            error_msg('Invalid old Password Inputed!');
            return false;
        }

        public static function updateCash()
        {
            if($_POST['submit'] != 'cash' || empty($_POST['cashAmount']))
            {
                return false;
            }

            if(self::getUserCash($_POST['UID']) >= 999999999)
            {
                error_msg("Account ID: {$_POST['UID']} already has maximum cash!");
                return false;
            }

            if(!empty($_POST['UID']))
            {
                Database::$membership->update('Accounts', ['Cash[+]' => $_POST['cashAmount']], ['AccountID' => $_POST['UID']]);
				
                success_msg("Successfully Given {$_POST['cashAmount']} to {$_POST['UID']}");
            }
            else
            {
                $checkAccount = self::GetAccountIDS();

                foreach($checkAccount as $row)
                {
                    if(self::getUserCash($row['AccountID']) >= 999999999)
                    {
                        error_msg("Account ID: {$row['AccountID']} already has maximum cash!");
                        return false;
                    }
                }

                Database::$membership->update('Accounts', ['Cash[+]' => $_POST['cashAmount']]);

                success_msg("Successfully Given {$_POST['cashAmount']} to All Accounts");
            }

            return true;
        }

        public static function getUserCash($UID)
        {
            $datas = Database::$membership->select('Accounts', 'Cash', ['AccountID' => $UID]);
            if (!empty($datas[0]))
            {
                return $datas[0];
            }
            return false;
        }

        public static function CheckEmailExists($email)
        {
            if (!empty($email)) {
                $datas = database::$membership->select('Accounts', '*', ['email' => Medoo::raw(':email', [':email' => $email])]);
                if (empty($datas[0]['AccountID'])) {
                    return true;
                }
            }
            return false;
        }

        public static function CheckUsernameExists($username)
        {
            if (!empty($username)) {
                $datas = Database::$membership->select('Accounts', '*', ['AccountName' => Medoo::raw(':AccountName', [':AccountName' => $username])]);
                if (empty($datas[0]['AccountID'])) {
                    return true;
                }
            }
            return false;
        }

        public static function CheckIPExists($ip)
        {
            if (!empty($ip)) {
                $datas = Database::$membership->select('IP', ['ip'], ['ip' => Medoo::raw(':ip', [':ip' => $ip])]);
                if (empty($datas[0])) {
                    return true;
                }
            }
            return false;
        }

        public static function GetCharacters($UID)
        {
            $datas = Database::$membership->select('Characters', 'CharacterID', ['AccountID' => $UID]);
            if (!empty($datas[0])){
                return $datas;
            }
            return false;
        }

        public static function GetCharacterName($CID)
        {
            $datas = Database::$world->select('Characters', ['CharacterID', 'CharacterName'], ['CharacterID' => $CID]);
            if (!empty($datas[0]['CharacterID'])){
                return $datas[0];
            }
            return false;
        }

        public static function GetCharacterInfo($CID)
        {
            $datas = Database::$world->select('CharacterStatus', ['CharacterID', 'CharacterLevel', 'JobCode', 'LastMapID'], ['CharacterID' => $CID]);
            if (!empty($datas[0]['CharacterID'])){
                return $datas[0];
            }
            return false;
        }

        public static function GetAccountIDS()
        {
            $datas = Database::$membership->select('Accounts', ['AccountID', 'AccountName']);
            if (!empty($datas[0]['AccountID'])){
                return $datas;
            }
            return false;
        }

        public static function GetAllAccount()
        {
            $datas = Database::$membership->select('Accounts', ['AccountID', 'AccountName', 'AccountLevelCode', 'email', 'Cash']);
            if (!empty($datas[0]['AccountID'])){
                return $datas;
            }
            return false;
        }
    }