<?php
    session_start();
    require_once $_SERVER['DOCUMENT_ROOT'] . "/vendor/autoload.php";
    require_once $_SERVER['DOCUMENT_ROOT'] . "/include/ip.php";
    require_once $_SERVER['DOCUMENT_ROOT'] . "/include/function.php";
    require_once $_SERVER['DOCUMENT_ROOT'] . "/include/database.php";
    require_once $_SERVER['DOCUMENT_ROOT'] . "/include/user.php";

    User::_postHandler();

    require_once $_SERVER['DOCUMENT_ROOT'] . "/models/index.php";
?>