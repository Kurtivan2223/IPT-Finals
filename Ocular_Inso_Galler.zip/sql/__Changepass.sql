/** ALTER PROCEDURE [dbo].[__Changepass]  if Procedure exists **/  
CREATE PROCEDURE [dbo].[__Changepass] 
	-- Add the parameters for the stored procedure here
	@AccountName NVARCHAR(12)
 ,@Password VARCHAR(12)
 ,@NewPassword VARCHAR(12)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @pass VARCHAR(32)
	DECLARE @newpassmd5 VARCHAR(32)
	SELECT @pass = RLKTPassword FROM dbo.Accounts WHERE AccountName = @AccountName
	SELECT @pass = @Password
    IF @pass = @Password
    BEGIN
		SELECT @newpassmd5 = UPPER(SUBSTRING(sys.fn_VarBinToHexStr(HASHBYTES('MD5', @NewPassword)),3,32));
		UPDATE dbo.Accounts SET RLKTPassword = @newpassmd5 WHERE AccountName = @AccountName
		SELECT 1 AS ChangeResult
		return
	END
	SELECT 2 AS ChangeResult
END

/*ALTER PROCEDURE [dbo].[__Changepass] 
	-- Add the parameters for the stored procedure here
	@AccountName NVARCHAR(12)
 ,@Password VARCHAR(12)
 ,@NewPassword VARCHAR(12)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @pass VARCHAR(32)
	DECLARE @passmd5 VARCHAR(32)
	DECLARE @newpassmd5 VARCHAR(32)
	SELECT @pass = RLKTPassword FROM dbo.Accounts WHERE AccountName = @AccountName
	SELECT @passmd5 = UPPER(SUBSTRING(sys.fn_VarBinToHexStr(HASHBYTES('MD5', @Password)),3,32));
    IF @pass = @passmd5
    BEGIN
		SELECT @newpassmd5 = UPPER(SUBSTRING(sys.fn_VarBinToHexStr(HASHBYTES('MD5', @NewPassword)),3,32));
		UPDATE dbo.Accounts SET RLKTPassword = @newpassmd5 WHERE AccountName = @AccountName
		SELECT 1 AS ChangeResult
		return
	END
	SELECT 2 AS ChangeResult
END*/