/**CREATE PROCEDURE [dbo].[__CreateAccount] if Procedure Doesn't exists **/
ALTER PROCEDURE [dbo].[__CreateAccount]      
(      
  @AccountName NVARCHAR(12)
 ,@Password VARCHAR(12)       
 ,@Email VARCHAR(60)
 ,@Token VARCHAR(20)
)      
AS      
BEGIN      
 SET NOCOUNT ON
 
 DECLARE @inyAccountLevelCode tinyint
 DECLARE @confirmation tinyint
 DECLARE @md5Password VARCHAR(32) = NULL
 SET @inyAccountLevelCode = 0;
 SET @confirmation = 0;
 SET @md5Password = UPPER(SUBSTRING(sys.fn_VarBinToHexStr(HASHBYTES('MD5', @Password)),3,32));        
   
      
  INSERT INTO Accounts       
  (      
   --AccountID int      
    AccountName    --nvarchar      
   ,AccountLevelCode   --tinyint      
   ,GameOption     --binary      
   ,CharacterCreateLimit  --tinyint      
   ,LastCharacterCreateDate --date      
   ,CharacterMaxCount   --tinyint      
   ,LastLoginDate    --datetime2      
   ,LastLogoutDate    --datetime2      
   ,LastLoginIP    --int      
   ,LastSessionID    --int      
   ,JoinIP      --int      
   ,RegisterDate    --datetime2      
   ,PublisherCode    --tinyint      
   ,GenderCode     --tinyint      
   ,BirthDate     --date      
   ,Passphrase     --varchar      
   ,KeySettingOption   --binary      
   ,SecondAuthPassphrase  --binary      
   --,SecondAuthFailCount  --tinyint      
   --,SecondAuthCode    --tinyint      
   --,SecondAuthLockFlag   --bit      
   ,LastSecondAuthNotifyDate --date      
   ,GamePadOption    --binary      
   ,NationalityCode   --tinyint      
   ,SecondAuthResetDate  --smalldatetime      
   ,ChannelPartnerCode   --tinyint      
   ,TotalDT     --int      
   ,AccountKey     --bigint      
   ,CharacterSortCode   --tinyint      
   ,ConnectNoticeFlag   --bit      
   ,NewbieRewardFlag   --bit      
   ,NewbieRewardDate   --datetime2      
   ,ReturnRewardFlag   --bit      
   ,LockFlag     --bit    
   ,RLKTPassword
   ,cash
   ,Email
	 ,token
	 ,confirmation
  )      
  VALUES      
  (      
   --AccountID int      
    @AccountName--AccountName --nvarchar      
   ,@inyAccountLevelCode --AccountLevelCode   --tinyint      
   ,NULL--GameOption    --binary      
   ,20--CharacterCreateLimit  --tinyint      
   ,NULL--LastCharacterCreateDate --date      
   ,20--CharacterMaxCount   --tinyint      
   ,NULL--LastLoginDate   --datetime2      
   ,NULL--LastLogoutDate   --datetime2      
   ,NULL--LastLoginIP    --int      
   ,NULL--LastSessionID   --int      
   ,NULL--JoinIP     --int      
   ,GETDATE()--RegisterDate  --datetime2      
   ,4--PublisherCode    --tinyint      
   ,NULL--GenderCode    --tinyint      
   ,NULL--BirthDate    --date      
   ,@md5Password--Passphrase  --varchar      
   ,NULL--KeySettingOption   --binary      
   ,NULL--SecondAuthPassphrase  --binary      
   --,NULL--SecondAuthFailCount  --tinyint      
   --,NULL--SecondAuthCode   --tinyint      
   --,NULL--SecondAuthLockFlag  --bit      
   ,NULL--LastSecondAuthNotifyDate --date      
   ,NULL--GamePadOption   --binary      
   ,NULL--NationalityCode   --tinyint      
   ,NULL--SecondAuthResetDate  --smalldatetime      
   ,NULL--ChannelPartnerCode  --tinyint      
   ,NULL--TotalDT     --int      
   ,NULL--AccountKey    --bigint      
   ,NULL--CharacterSortCode  --tinyint      
   ,NULL--ConnectNoticeFlag  --bit      
   ,NULL--NewbieRewardFlag   --bit      
   ,NULL--NewbieRewardDate   --datetime2      
   ,NULL--ReturnRewardFlag   --bit      
   ,0--LockFlag     --bit   
   ,@md5Password
   ,500000
   ,@Email
	 ,@Token
	 ,@confirmation
  )       

      
 SET NOCOUNT OFF      
END