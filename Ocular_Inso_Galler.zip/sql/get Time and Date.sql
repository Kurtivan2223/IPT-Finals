DECLARE @dtmServerTime datetime

SET @dtmServerTime = GETDATE();

SELECT @dtmServerTime AS Result

/* 24 hours format in time*/