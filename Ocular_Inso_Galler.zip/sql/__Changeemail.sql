/* CREATE PROCEDURE [dbo].[__Changeemail]  */
CREATE PROCEDURE [dbo].[__Changeemail] 
	-- Add the parameters for the stored procedure here
  @AccountName NVARCHAR(20)
 ,@Emails VARCHAR(60)
 ,@NewEmail VARCHAR(60)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @mail VARCHAR(60)
	SELECT @mail = Email FROM dbo.Accounts WHERE AccountName = @AccountName
    IF @mail = @Emails
    BEGIN
		UPDATE dbo.Accounts SET Email = @NewEmail WHERE AccountName = @AccountName
		SELECT 1 AS ChangeResult
		RETURN
	END
	SELECT 2 AS ChangeResult
END