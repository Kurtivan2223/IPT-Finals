-- ALTER PROCEDURE [dbo].[__cash] 
CREATE PROCEDURE [dbo].[__cash]
  @cash VARCHAR(60)
AS

BEGIN
	SET NOCOUNT ON;
	
	UPDATE dbo.Accounts SET cash = @cash + cash
	
	SELECT cash FROM dbo.Accounts AS ChangeResult
END